1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/cca125d6f043f51f.js","/_next/static/chunks/2caf1cf0fe5e2aa0.js","/_next/static/chunks/b9c8a56c4775258c.js","/_next/static/chunks/a9eca9f425f14509.js"],"default"]
3:I[37457,["/_next/static/chunks/cca125d6f043f51f.js","/_next/static/chunks/2caf1cf0fe5e2aa0.js","/_next/static/chunks/b9c8a56c4775258c.js","/_next/static/chunks/a9eca9f425f14509.js"],"default"]
0:{"buildId":"YRIM4FQ503p10QimCot0B","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
