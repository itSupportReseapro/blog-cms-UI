:HL["/_next/static/chunks/671ccdb0d32648a2.css","style"]
:HL["/_next/static/chunks/d7b8375b9b2691bd.css","style"]
:HL["/_next/static/chunks/9923ab1f7173199a.css","style"]
:HL["/_next/static/chunks/97bafded73a0cf44.css","style"]
:HL["/_next/static/chunks/abcb800dbe984f48.css","style"]
:HL["/_next/static/chunks/d0c0499c053e67fe.css","style"]
0:{"buildId":"YRIM4FQ503p10QimCot0B","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"(protected)","paramType":null,"paramKey":"(protected)","hasRuntimePrefetch":false,"slots":{"children":{"name":"blog","paramType":null,"paramKey":"blog","hasRuntimePrefetch":false,"slots":{"children":{"name":"activity-log","paramType":null,"paramKey":"activity-log","hasRuntimePrefetch":false,"slots":{"children":{"name":"create","paramType":null,"paramKey":"create","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
