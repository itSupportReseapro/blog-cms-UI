:HL["/_next/static/chunks/671ccdb0d32648a2.css","style"]
:HL["/_next/static/chunks/15934ae405d57d80.css","style"]
:HL["/_next/static/chunks/abcb800dbe984f48.css","style"]
:HL["/_next/static/chunks/9923ab1f7173199a.css","style"]
0:{"buildId":"YRIM4FQ503p10QimCot0B","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"(public)","paramType":null,"paramKey":"(public)","hasRuntimePrefetch":false,"slots":{"children":{"name":"signup","paramType":null,"paramKey":"signup","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
