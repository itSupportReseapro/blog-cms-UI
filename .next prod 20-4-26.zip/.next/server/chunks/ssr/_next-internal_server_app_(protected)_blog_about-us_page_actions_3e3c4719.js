module.exports=[2210,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_blog_about-us_page_actions_3e3c4719.js.map