module.exports=[60010,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_blog_activity-log_page_actions_4cabd197.js.map