module.exports=[57935,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_blog_blogs_%5Bid%5D_edit_page_actions_4d97bd66.js.map