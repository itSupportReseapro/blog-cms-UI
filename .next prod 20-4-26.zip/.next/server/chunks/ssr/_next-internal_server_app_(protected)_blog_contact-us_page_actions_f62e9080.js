module.exports=[2639,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_blog_contact-us_page_actions_f62e9080.js.map