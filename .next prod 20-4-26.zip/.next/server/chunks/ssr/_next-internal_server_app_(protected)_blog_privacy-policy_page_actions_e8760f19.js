module.exports=[57384,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_blog_privacy-policy_page_actions_e8760f19.js.map