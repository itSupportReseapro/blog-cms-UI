module.exports=[34972,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_blog_activity-log_create_page_actions_e882c84e.js.map