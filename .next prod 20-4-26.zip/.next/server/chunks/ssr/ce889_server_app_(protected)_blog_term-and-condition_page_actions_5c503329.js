module.exports=[54663,(a,b,c)=>{}];

//# sourceMappingURL=ce889_server_app_%28protected%29_blog_term-and-condition_page_actions_5c503329.js.map