globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f1b4d49aa9e249c5.js",
    "static/chunks/45a935b3e76bc441.js",
    "static/chunks/aee6c7720838f8a2.js",
    "static/chunks/7d6514a90169e63d.js",
    "static/chunks/185059a765262b23.js",
    "static/chunks/turbopack-4d9e3209f10ba3d7.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];