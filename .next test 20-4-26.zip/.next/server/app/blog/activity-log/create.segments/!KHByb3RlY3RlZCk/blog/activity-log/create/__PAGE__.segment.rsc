1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a9eca9f425f14509.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"qeC1EfLC02OWIqtxU9DlQ","rsc":["$","$1","c",{"children":[["$","section",null,{"children":[["$","h1",null,{"children":"Create Post"}],["$","p",null,{"children":"Create post form placeholder."}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null
