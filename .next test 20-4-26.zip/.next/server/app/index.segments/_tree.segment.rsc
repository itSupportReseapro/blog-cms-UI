:HL["/_next/static/chunks/671ccdb0d32648a2.css","style"]
0:{"buildId":"qeC1EfLC02OWIqtxU9DlQ","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
