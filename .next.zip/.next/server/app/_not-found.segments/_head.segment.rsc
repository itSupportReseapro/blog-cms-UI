1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/cd43556c216733d5.js","/_next/static/chunks/2bd121a392309b82.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/cd43556c216733d5.js","/_next/static/chunks/2bd121a392309b82.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"692BmR-BUtH3vHMYVmuTe","rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Blog CMS"}],["$","meta","1",{"name":"description","content":"Blog content management system"}]]}]}]}],null]}],"loading":null,"isPartial":false}
