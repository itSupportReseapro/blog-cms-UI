1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/017419cddf06d9a8.js","/_next/static/chunks/2caf1cf0fe5e2aa0.js","/_next/static/chunks/b9c8a56c4775258c.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
3:I[37457,["/_next/static/chunks/017419cddf06d9a8.js","/_next/static/chunks/2caf1cf0fe5e2aa0.js","/_next/static/chunks/b9c8a56c4775258c.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
0:{"buildId":"WFTbQG-Go1TKqLZnEoDiv","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
