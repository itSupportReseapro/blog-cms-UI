1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/cd43556c216733d5.js","/_next/static/chunks/2bd121a392309b82.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
3:I[37457,["/_next/static/chunks/cd43556c216733d5.js","/_next/static/chunks/2bd121a392309b82.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
0:{"buildId":"692BmR-BUtH3vHMYVmuTe","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
