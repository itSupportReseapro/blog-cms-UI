1:"$Sreact.fragment"
2:I[42370,["/_next/static/chunks/cd43556c216733d5.js","/_next/static/chunks/2bd121a392309b82.js","/_next/static/chunks/baf8c2591b729417.js","/_next/static/chunks/b3e2facd69491d0a.js"],"default"]
3:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
4:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
:HL["/_next/static/chunks/89e72316f7e90249.css","style"]
0:{"buildId":"692BmR-BUtH3vHMYVmuTe","rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/89e72316f7e90249.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/b3e2facd69491d0a.js","async":true}]],["$","$L2",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]}]]}],"loading":null,"isPartial":false}
