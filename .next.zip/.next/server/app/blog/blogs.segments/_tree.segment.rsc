:HL["/_next/static/chunks/e0870567513df72f.css","style"]
:HL["/_next/static/chunks/89e72316f7e90249.css","style"]
:HL["/_next/static/chunks/a924b7f0525fa3f2.css","style"]
:HL["/_next/static/chunks/e4e8b2c5d11f0cdf.css","style"]
:HL["/_next/static/chunks/1ee6d2402ca128bb.css","style"]
0:{"buildId":"692BmR-BUtH3vHMYVmuTe","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"(protected)","paramType":null,"paramKey":"(protected)","hasRuntimePrefetch":false,"slots":{"children":{"name":"blog","paramType":null,"paramKey":"blog","hasRuntimePrefetch":false,"slots":{"children":{"name":"blogs","paramType":null,"paramKey":"blogs","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
