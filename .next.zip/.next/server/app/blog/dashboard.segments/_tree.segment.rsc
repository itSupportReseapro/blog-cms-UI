:HL["/_next/static/chunks/e0870567513df72f.css","style"]
:HL["/_next/static/chunks/89e72316f7e90249.css","style"]
:HL["/_next/static/chunks/8cdbf3a9a042efe9.css","style"]
:HL["/_next/static/chunks/2cfc240f55e6e794.css","style"]
0:{"buildId":"692BmR-BUtH3vHMYVmuTe","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"(protected)","paramType":null,"paramKey":"(protected)","hasRuntimePrefetch":false,"slots":{"children":{"name":"blog","paramType":null,"paramKey":"blog","hasRuntimePrefetch":false,"slots":{"children":{"name":"dashboard","paramType":null,"paramKey":"dashboard","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
