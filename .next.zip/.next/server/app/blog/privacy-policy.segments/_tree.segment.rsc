:HL["/_next/static/chunks/2e094f3e695df48d.css","style"]
:HL["/_next/static/chunks/30539aa01bbea9f2.css","style"]
:HL["/_next/static/chunks/73a02a22e32c9c5e.css","style"]
:HL["/_next/static/chunks/1e7ca3862943909e.css","style"]
:HL["/_next/static/chunks/d43c535e4102ff31.css","style"]
:HL["/_next/static/chunks/3e458d33071ab2f6.css","style"]
0:{"buildId":"kpsH-bMeYR-zRhthyScui","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"(protected)","paramType":null,"paramKey":"(protected)","hasRuntimePrefetch":false,"slots":{"children":{"name":"blog","paramType":null,"paramKey":"blog","hasRuntimePrefetch":false,"slots":{"children":{"name":"privacy-policy","paramType":null,"paramKey":"privacy-policy","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
