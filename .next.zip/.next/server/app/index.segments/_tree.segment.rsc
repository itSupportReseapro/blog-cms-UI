:HL["/_next/static/chunks/2e094f3e695df48d.css","style"]
0:{"buildId":"vTFv4ZU43F9FR-J0HWske","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
