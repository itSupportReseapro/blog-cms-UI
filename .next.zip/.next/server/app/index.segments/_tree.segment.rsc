:HL["/_next/static/chunks/e0870567513df72f.css","style"]
0:{"buildId":"692BmR-BUtH3vHMYVmuTe","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
