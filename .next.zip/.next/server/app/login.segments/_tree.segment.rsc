:HL["/_next/static/chunks/671ccdb0d32648a2.css","style"]
:HL["/_next/static/chunks/abcb800dbe984f48.css","style"]
:HL["/_next/static/chunks/9923ab1f7173199a.css","style"]
:HL["/_next/static/chunks/a4ac448847fe2e42.css","style"]
0:{"buildId":"WFTbQG-Go1TKqLZnEoDiv","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"(public)","paramType":null,"paramKey":"(public)","hasRuntimePrefetch":false,"slots":{"children":{"name":"login","paramType":null,"paramKey":"login","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
