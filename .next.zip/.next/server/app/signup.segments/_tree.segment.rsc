:HL["/_next/static/chunks/e0870567513df72f.css","style"]
:HL["/_next/static/chunks/9f7f2013ac3ec626.css","style"]
:HL["/_next/static/chunks/e4e8b2c5d11f0cdf.css","style"]
0:{"buildId":"692BmR-BUtH3vHMYVmuTe","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"(public)","paramType":null,"paramKey":"(public)","hasRuntimePrefetch":false,"slots":{"children":{"name":"signup","paramType":null,"paramKey":"signup","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
