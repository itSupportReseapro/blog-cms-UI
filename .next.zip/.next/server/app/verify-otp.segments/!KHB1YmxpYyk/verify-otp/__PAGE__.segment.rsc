1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"692BmR-BUtH3vHMYVmuTe","rsc":["$","$1","c",{"children":[["$","main",null,{"style":{"padding":"24px"},"children":[["$","h1",null,{"children":"Verify OTP"}],["$","p",null,{"children":"OTP verification flow placeholder."}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null
