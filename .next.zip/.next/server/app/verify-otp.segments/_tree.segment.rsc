:HL["/_next/static/chunks/2e094f3e695df48d.css","style"]
:HL["/_next/static/chunks/abcb800dbe984f48.css","style"]
:HL["/_next/static/chunks/73a02a22e32c9c5e.css","style"]
0:{"buildId":"kpsH-bMeYR-zRhthyScui","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"(public)","paramType":null,"paramKey":"(public)","hasRuntimePrefetch":false,"slots":{"children":{"name":"verify-otp","paramType":null,"paramKey":"verify-otp","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
