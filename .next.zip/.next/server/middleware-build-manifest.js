globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f1b4d49aa9e249c5.js",
    "static/chunks/6b7a6efd969cea7c.js",
    "static/chunks/aee6c7720838f8a2.js",
    "static/chunks/7d6514a90169e63d.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/turbopack-d0d55d6928bbf857.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];